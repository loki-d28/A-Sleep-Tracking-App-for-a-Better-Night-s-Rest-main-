version https://git-lfs.github.com/spec/v1
oid sha256:959cb2b067e5df4b10157e90f7887e0f5485f706e19dd1af039d67a8bac6a1aa
size 677
