version https://git-lfs.github.com/spec/v1
oid sha256:41cbff2c68bcb6788152ee87f134eef4bf2a5aab2d2d8cbb65fa5d68174c6274
size 2875
