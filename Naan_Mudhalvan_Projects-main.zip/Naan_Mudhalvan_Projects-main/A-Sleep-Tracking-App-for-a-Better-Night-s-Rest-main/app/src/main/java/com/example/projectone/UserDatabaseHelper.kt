version https://git-lfs.github.com/spec/v1
oid sha256:7676f17a839ff32134c97f50095d6415280ecb434dfa20d5a4dbe1b0e780f4b0
size 4433
