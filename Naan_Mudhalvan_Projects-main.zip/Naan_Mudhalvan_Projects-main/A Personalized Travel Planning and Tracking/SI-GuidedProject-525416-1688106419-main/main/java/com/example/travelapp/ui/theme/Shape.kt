version https://git-lfs.github.com/spec/v1
oid sha256:e1ac09874d16531267cf562ab01c7f5cb8cd8af4a82d27123d581f2788f68d4c
size 312
