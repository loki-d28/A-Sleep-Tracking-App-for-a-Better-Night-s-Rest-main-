version https://git-lfs.github.com/spec/v1
oid sha256:3cd00e71b0a279a4db744ed4284d16ecf5fca8f58431a3d49c3bae5fbca2a018
size 6516
