version https://git-lfs.github.com/spec/v1
oid sha256:942cc750059a04ec661f5c62518a88d4524656c1ce404a0e4b60f022e928bb1d
size 2672
